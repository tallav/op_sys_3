#include <string>

using std::string;

void InitializeOperatingSystemTestSubTests();
string aschiiToString(int aschii);